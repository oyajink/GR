//Get the button
var mybutton = document.getElementById("totopBtn");
// When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function() {scrollFunction()};
  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      mybutton.style.display = "block";
    } else {
      mybutton.style.display = "none";
    }
  }
//ajax jquery
  $.getJSON('_assets/data/lumo.json',function(data){
    var pl = data.content;
    var content = '';
  
    $.each(pl, function (i, data){
      content += `
        <div class="column">
          <table cellspacing="0" cellpadding="0" border="1px solid #EBD2B4;" width="100%">
            <h4>Kitab ${data.title}<em>&nbsp;(${data.durasi})</em>
            </h4>
              <tr>
                <td class="vcontrol">
                <center>
                  <a class="big-link" id="#${data.video}" data-reveal-id="${data.id}" href="#${data.video}" data-animation="fade">
                    <div class="thumbnail" style="background-image: url(${data.thumb});">
                      <div class="overlay">
                        <div class="playbutton">
                          <p>
                            <i class="fa fa-play" style="color: #00A7F6;"></i>
                          </p>
                        </div>
                      </div>
                    </div>
                  </a>
                </center>
                  <p align="center">
                    <a class="dbutton1"  href="${data.video}" download>Download Video</a>
                  </p>
                </td>
              </tr>
            </table>
          </div>
          <div id="${data.id}" class="reveal-modal xlarge" data-reveal aria-labelledby="videoModalTitle" aria-hidden="true" role="dialog" style="display:block;">
            <div class="content-video">
              <h3>Kitab ${data.title}</h3>
              <center>
                <video class="video" controls preload="none">
                  <source src="${data.video}" type="video/mp4">
                  <track src="${data.subtitle}" kind="subtitles" srclang="en" label="English">
                  Your browser does not support the video tag.
                </video>
                </center>
            </div>
            <a class="close-reveal-modal">&#215;</a>
          </div>
          
        `;
    });
    $('#content').html(content);
  });